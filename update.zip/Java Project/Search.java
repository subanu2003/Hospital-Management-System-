
/*import java.lang.*;
import javax.swing.*;

public class Search extends JFrame{
	//String name;
	JLabel userLabel, passLabel;
	JTextField userTF;
	JPasswordField passTF;
	JButton lgnBtn;
	JPanel panel;
	
	public Search(){
		super("My First GUI");
		this.setSize(500,500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		userLabel = new JLabel("Username: ");
		userLabel.setBounds(50,20,80,20); //x,y,width,length
		panel.add(userLabel);
		
		
		passLabel = new JLabel("Password: ");
		passLabel.setBounds(50,45,80,20); 
		panel.add(passLabel);
		
		userTF = new JTextField();
		userTF.setBounds(130,20,100,20);
		panel.add(userTF);
		
		passTF = new JPasswordField();
		passTF.setBounds(130,45,100,20);
		panel.add(passTF);
		
		lgnBtn = new JButton("Login");
		lgnBtn.setBounds(100,70,80,20);
		panel.add(lgnBtn);
		
		this.add(panel);
	}
	
}*/
