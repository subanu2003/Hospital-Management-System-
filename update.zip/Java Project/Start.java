import java.lang.*;

public class Start{
	public static void main(String []args){
		
		AddDoctor ad =  new AddDoctor();
		ad.setVisible(true);
		
	    //DoctorList dl = new DoctorList();
		//dl.setVisible(true);
		
		
		DoctorInfo di =  new DoctorInfo();
		di.setVisible(true);
	}
}
